
<li><a href="#" style="display:none">Search</a>
  <ul id="searchnav">
    <li>
      <form style="padding:20px" id="quicksearchform">
      <div class="form-group">
      <label>URN</label>
      <input class="form-control input-sm" type="text" name="urn" placeholder="Search by unique reference number"/>
      </div>
      <div class="form-group">
      <label>Reference Number</label>
      <input class="form-control input-sm" type="text" name="client_ref" placeholder="Search by client reference number"/>
      </div>
       <div class="form-group">
      <label>Email Address</label>
      <input class="form-control input-sm" type="text" name="contact_email" placeholder="Search by email address"/>
      </div>
       <div class="form-group">
      <label>Telephone</label>
      <input class="form-control input-sm" type="text" name="all_phone" placeholder="Search by full or part telephone number"/>
      </div>
      <div class="form-group">
      <label>Name</label>
      <input class="form-control input-sm" type="text" name="all_names" placeholder="Search by company or contact name"/>
      </div>
      <div class="form-group">
      <button class="btn btn-primary btn-sm" id="startsearch">Search</button> <div class="pull-right" id="quicksearchresult"></div>
      </div>
      </form>
    </li>
  </ul>
</li>
