	<div class="content_wrap footer_bg">
		<div id="footer" class="content clearfix">
			<div class="float_l" style="margin-top:35px;">
				Copyright &copy; <?php echo date('Y');?>, Rob Hussey, All Rights Reserved.<br/>
			</div>
			<div class="float_r" style="margin-top:20px; text-align:center;">
				flexi cart was designed and developed by<br/>
				<a href="http://haseydesign.com">
					<img src="<?php echo $includes_dir; ?>images/haseydesign.png"/>
				</a>
			</div>
		</div>
	</div>