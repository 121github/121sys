	<meta name="robots" content="index, follow"/>
	<meta name="designer" content="haseydesign - Rob Hussey : rob @ haseydesign .com"/> 
	<meta name="copyright" content="Copyright &copy; <?php echo date('Y');?>, Rob Hussey, All Rights Reserved"/>
	<meta http-equiv="imagetoolbar" content="no"/>	
	
	<link rel="stylesheet" href="<?php echo $includes_dir;?>css/global.css?v=0.1">
	<link rel="stylesheet" href="<?php echo $includes_dir;?>css/structure.css?v=0.1">